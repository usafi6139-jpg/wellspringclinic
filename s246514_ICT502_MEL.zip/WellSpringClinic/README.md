# WellSpring Family Clinic — Website

A responsive, accessible clinic website built with semantic HTML5, modern CSS, and vanilla JavaScript.

## Pages
- `/index.html` — Home
- `/services.html` — Services
- `/bmi.html` — BMI Calculator (with categories)
- `/appointment.html` — Appointment Request (Formspree-ready)
- `/about.html` — About Us
- `/contact.html` — Contact (Formspree-ready + map)

## Formspree Setup
1. Go to https://formspree.io/ and create a project.
2. Create a form and copy its endpoint, which looks like `https://formspree.io/f/abcdexyz`.
3. In `appointment.html` and `contact.html`, replace `https://formspree.io/f/yourcode` with your endpoint.
4. (Optional) In Formspree settings, enable reCAPTCHA or spam protection.

## Hosting (GitHub Pages)
1. Create a GitHub repo and push this folder's contents.
2. In your repo settings, enable **Pages** with the root directory.
3. Access your site at the provided GitHub Pages URL.

## Hosting (Netlify)
1. Drag & drop this folder into Netlify (app.netlify.com) or connect your Git repo.
2. Netlify will deploy automatically. Your site will be live at a generated URL.

## Local Preview
Double-click `index.html` to open in a browser.

## Accessibility & SEO
- Semantic landmarks: `<header>`, `<nav>`, `<main>`, `<footer>`.
- Labels/ARIA for forms and navigation.
- Alt text and `<title>` on SVG logo.
- Mobile-friendly viewport meta.
- Descriptive titles and meta descriptions for each page.
- High contrast buttons and focus styles.

## License
MIT

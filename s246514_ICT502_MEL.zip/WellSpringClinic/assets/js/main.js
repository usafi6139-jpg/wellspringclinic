// Mobile nav toggle
const navToggle = document.querySelector('.nav-toggle');
const primaryNav = document.getElementById('primary-nav');
if (navToggle && primaryNav){
  navToggle.addEventListener('click', () => {
    const expanded = navToggle.getAttribute('aria-expanded') === 'true';
    navToggle.setAttribute('aria-expanded', String(!expanded));
    primaryNav.classList.toggle('open');
  });
}

// Scroll reveal animations
const io = new IntersectionObserver((entries) => {
  for (const e of entries){
    if (e.isIntersecting){
      e.target.classList.add('visible');
      io.unobserve(e.target);
    }
  }
},{threshold:0.15});
document.querySelectorAll('.reveal').forEach(el => io.observe(el));

// Appointment & contact forms: basic client-side validation + friendly status text
function attachAjaxForm(formId, statusId){
  const form = document.getElementById(formId);
  const status = document.getElementById(statusId);
  if (!form || !status) return;

  form.addEventListener('submit', async (ev) => {
    ev.preventDefault();
    status.textContent = '';

    if (!form.checkValidity()){
      status.textContent = 'Please complete the required fields.';
      return;
    }
    const data = new FormData(form);
    try{
      const res = await fetch(form.action, { method: form.method || 'POST', body: data, headers: { 'Accept': 'application/json' } });
      if (res.ok){
        status.textContent = 'Thanks! Your request has been sent.';
        form.reset();
      } else {
        status.textContent = 'Hmm, something went wrong. Please try again later.';
      }
    } catch(err){
      status.textContent = 'Network error. Check your connection and try again.';
    }
  });
}

attachAjaxForm('appointment-form','appointment-status');
attachAjaxForm('contact-form','contact-status');

// BMI calculator logic
const bmiForm = document.getElementById('bmi-form');
if (bmiForm){
  bmiForm.addEventListener('submit', (ev) => {
    ev.preventDefault();
    const h = parseFloat(document.getElementById('height').value);
    const u = document.getElementById('height-unit').value;
    const w = parseFloat(document.getElementById('weight').value);
    const out = document.getElementById('bmi-output');

    if (!h || !w || h <= 0 || w <= 0){
      out.textContent = 'Please enter valid height and weight.';
      return;
    }
    const meters = (u === 'cm') ? (h / 100) : h;
    const bmi = w / (meters * meters);
    let cat = '';
    if (bmi < 18.5) cat = 'Underweight';
    else if (bmi < 25) cat = 'Normal';
    else if (bmi < 30) cat = 'Overweight';
    else cat = 'Obese';

    out.textContent = `Your BMI is ${bmi.toFixed(1)} — ${cat}`;
  });
}
